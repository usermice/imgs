# redis-sts

- https://rancher.com/blog/2019/deploying-redis-cluster/

# 创建 statefulset 类型资源
$ kubectl apply -f redis-sts.yml

$ kubectl get pods -l app=redis-cluster

# 创建 service 
$ kubectl apply -f redis-svc.yml

$ kubectl get svc redis-cluster

# 初始化 redis cluster
$ kubect exec -it redis-cluster-0 -- redis-cli --cluster create --cluster-replicas 1 $(kubectl get pods -l app=redis-cluster -o jsonpath='{range.items[*]}{.status.podIP}:6379 ')

# 验证集群
$ kubectl exec -it redis-cluster-0 -- redis-cli cluster info

$ for x in $(seq 0 5); do echo "redis-cluster-$x"; kubectl exec redis-cluster-$x -- redis-cli role; echo; done

# 部署点击计数器应用
$ kubectl apply -f app-deployment-service.yaml


