#!/bin/bash
# 获取tcp连接状态

case $1 in
	LISTEN)
		num=`netstat -atnl | grep -E "\bLISTEN\b" | wc -l`
		echo $num
    	;;
    SYN_SENT)
		num=`netstat -atnl | grep -E "\bSYN_SENT\b" | wc -l`
		echo $num
    	;;
    SYN_RECV)
		num=`netstat -atnl | grep -E "\bSYN_RECV\b" | wc -l`
		echo $num
    	;;
    ESTABLISHED)
		num=`netstat -atnl | grep -E "\bESTABLISHED\b" | wc -l`
		echo $num
    	;;
    FIN_WAIT1)
		num=`netstat -atnl | grep -E "\bFIN_WAIT1\b" | wc -l`
		echo $num
    	;;
    FIN_WAIT2)
		num=`netstat -atnl | grep -E "\bFIN_WAIT2\b" | wc -l`
		echo $num
    	;;
    CLOSE_WAIT)
		num=`netstat -atnl | grep -E "\bCLOSE_WAIT\b" | wc -l`
		echo $num
    	;;
    TIME_WAIT)
		num=`netstat -atnl | grep -E "\bTIME_WAIT\b" | wc -l`
		echo $num
    	;;
    LAST_ACK)
		num=`netstat -atnl | grep -E "\bLAST_ACK\b" | wc -l`
		echo $num
		;;
	CLOSING)
		num=`netstat -atnl | grep -E "\bCLOSING\b" | wc -l`
		echo $num
    	;;
    CLOSED)
		num=`netstat -atnl | grep -E "\bCLOSED\b" | wc -l`
		echo $num
    	;;
    *)
		echo "USER /bin/bash $0 (CLOSED|LISTEN|SYN_RECV|SYN_SENT|ESTABLISHED|FIN_WAIT1|FIN_WAIT2|CLOSING|TIME_WAIT|CLOSE_WAIT|LAST_ACK)"
esac
