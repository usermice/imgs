0.01版

 conf 下為Zabbix呼叫的KEY值設定檔
 
 scriptt下為Zabbix呼叫執行檔案
 
 key下為公鑰檔
 
 runset_script下為手動執行用的檔案
 
 TEST
 
 test
 
 test

新增slot webhook