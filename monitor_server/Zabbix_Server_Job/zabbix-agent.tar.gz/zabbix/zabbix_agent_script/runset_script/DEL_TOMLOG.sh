#!/bin/bash/
tomdate="$(date +"%Y%m%d%s")"
tomlog='/opt/lucky/logs/tomcat*'
#echo $tomdate
#echo $tomlog
find   $tomlog/*.log  -type f -ctime 7 -exec rm -f  {}    \;
find $tomlog/*.txt  -type f -ctime 7 -exec rm -f {}   \;
