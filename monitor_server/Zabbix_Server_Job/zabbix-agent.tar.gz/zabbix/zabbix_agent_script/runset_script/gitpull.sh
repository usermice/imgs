#!/bin/sh

export GIT_SSL_NO_VERIFY=true
git_serach_ip=`git config --list |grep remote.origin.url | cut -d "@" -f 2 |cut -d ":" -f 1`
#echo $git_serach_ip
cd /home/mtadmin/apps/zabbix/zabbix_agent_script/

if [ "$git_serach_ip"  == gitlab.idcduty.com ];then
#echo "ok"
git pull git@gitlab.idcduty.com:jackwu/zabbix_agent_script.git
else
#echo "no"
git remote set-url origin git@gitlab.idcduty.com:jackwu/zabbix_agent_script.git

fi

#cd /home/mtadmin/apps/zabbix/zabbix_agent_script/

#git pull ssh://git@59.124.243.25:1220/root/zabbix_agent_script.git

