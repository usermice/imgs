#!/bin/bash

TODAY=`ps -ef |grep zabbix | wc -l`

echo $TODAY

echo -n "你好！請輸入你的年齡："
read MY_AGE

if [ $MY_AGE -eq 18 ]; then
	echo "恭喜你，你剛滿18歲！"
elif [ $MY_AGE -lt 18 ]; then
    echo "你還未成年喔！"
else
    echo "你已經成年了"
fi

echo "你輸入的年齡是 $MY_AGE 歲"
