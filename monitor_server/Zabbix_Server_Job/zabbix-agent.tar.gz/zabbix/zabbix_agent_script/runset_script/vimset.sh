echo ":colorscheme desert" >> ~/.vimrc

