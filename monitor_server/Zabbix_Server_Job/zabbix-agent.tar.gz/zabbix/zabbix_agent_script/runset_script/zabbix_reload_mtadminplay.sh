#!/bin/bash

pkill -9 zabbix_agentd
/home/mtadmin/apps/zabbix/sbin/zabbix_agentd
