#!/bin/bash
yum install -y ntpd nano nc wget vim unzip ntp
yum install bash-completion -y && source /etc/profile
#判斷是否已經下載gitlab上的資料
cd /home/mtadmin/apps/zabbix/
if [ ! -d "zabbix_agent_script"  ];then
su  mtadmin -c "
cd /home/mtadmin/apps/zabbix/
git clone  https://itman:work5net9@gitlab.idcduty.com/jackwu/zabbix_agent_script.git
"
else
    echo "========================Git已經Clone========================"
fi
systemctl enable ntpd
systemctl start ntpd
#判斷是否已設定zabbidinclude
grep "zabbix_agent_script" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
if [ $? -ne 0 ];then
        su mtadmin -c "
        echo 'Include=/home/mtadmin/apps/zabbix/zabbix_agent_script/conf/*.conf' >>/home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
        pkill -9 zabbix_agentd
		/home/mtadmin/apps/zabbix/sbin/zabbix_agentd
	"
else
        echo "========================Zabbix_Include已經做過了========================"
fi

#.ssh檔寫入
su mtadmin -c "
mkdir /home/mtadmin/.ssh
cp -fr /home/mtadmin/apps/zabbix/zabbix_agent_script/key/* /home/mtadmin/.ssh/
cd /home/mtadmin/.ssh/
echo '    Host gitlab.idcduty.com' >> config
echo '     IdentityFile ~/.ssh/id_rsa.itmangitlab' >> config
chmod 600 /home/mtadmin/.ssh/id_rsa.itmangitlab
chmod 600 /home/mtadmin/.ssh/config
"
echo "========================公鑰導入完成========================"

#設定Zabbix主機
grep "103.139.241.119" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
if [ $? -ne 0 ];then
    sed -i  "s/Server=103.86.85.91/Server=103.139.241.119/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
    #sed -i  "s/ServerActive=103.86.85.91:10051/ServerActive=103.139.241.119:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
else
        echo "========================zabbixConf_IP已存在========================"
fi


#設定GITuser
git config --global user.email "itman@example.com"
git config --global user.name "itman"
echo "========================GIT設定========================" 

su mtadmin -c "
pkill -9 zabbix_agentd
/home/mtadmin/apps/zabbix/sbin/zabbix_agentd
"
echo "========================重啟ZABBIX完成========================" 
grep "ecktLsEmENWQJN4E" /home/mtadmin/.ssh/known_hosts
if [ $? -ne 0 ];then
	echo "========================known_host_IP設定========================" 
    su mtadmin -c "
    echo 'gitlab.idcduty.com ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBI6M9ur9MxfxhrUp/Eb81Ko5m1LPtY1EQC3Udapc9v9s65FUSEkx3KupAe+9vXAjWk8ecktLsEmENWQJN4E/i6Y=' >> /home/mtadmin/.ssh/known_hosts
    "
else
        echo "=========================known_host_IP已存在========================"
fi
su mtadmin -c "
       cd /home/mtadmin/apps/zabbix/zabbix_agent_script/
       git pull
    "
chown -R mtadmin.mtadmin /home/mtadmin/apps/zabbix/zabbix_agent_script/.git/FETCH_HEAD
grep "185.167.15.200" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
if [ $? -ne 0 ];then
    sed -i  "s/Server=103.139.241.119/Server=103.139.241.119,185.167.15.200,185.167.15.201,185.167.15.202,185.167.15.203,185.167.15.204,185.167.15.205/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
    sed -i  "s/ServerActive=103.86.85.91:10051/ServerActive=103.139.241.119:10051,185.167.15.200:10051,185.167.15.201:10051,185.167.15.202:10051,185.167.15.203:10051,185.167.15.204:10051,185.167.15.205:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
pkill -9 zabbix_agentd
su mtadmin -c "/home/mtadmin/apps/zabbix/sbin/zabbix_agentd"
else
        echo "========================NEW!!!!zabbixConf_IP已存在========================"
fi
echo "================zabbix，設定IP==========設定前"
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Server="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^ServerActive="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Hostname="
echo "================zabbix，防火牆IP==========設定前"
firewall-cmd --permanent --ipset=zabbix_whitelist --get-entries
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source ipset=zabbix_whitelist port port="10050" protocol="tcp" accept'
firewall-cmd --reload
firewall-cmd --permanent --new-ipset=zabbix_whitelist --type=hash:ip
firewall-cmd --reload
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=103.139.241.119
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.192/26
firewall-cmd --reload
echo "================zabbix，防火牆IP==========設定後"
firewall-cmd --permanent --ipset=zabbix_whitelist --get-entries
echo "======================"
echo "zabbixSetting"
echo "================zabbix，設定IP==========設定後"
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Server="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^ServerActive="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Hostname="

echo "Line End"