#!/bin/bash
    export GIT_SSL_NO_VERIFY=true
    git config --global http.sslVerify "false"
    cd /home/mtadmin/apps/zabbix/zabbix_agent_script/
    git fetch --all
    git reset --hard origin/master
    #git pull git@gitlab.idcduty.com/jackwu/zabbix_agent_script:jackwu/zabbix_agent_script.git 
    #git pull git@gitlab.idcduty.com:jackwu/zabbix_agent_script.git
    git pull
    git pull -u origin master