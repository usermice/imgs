#!/bin/bash
case $1 in
'mysqld')
ps -ef  |grep $1 |grep  -v "grep" |wc -l
;;
'tomcat')
ps -ef |grep $1 |grep  -v "grep" |wc -l
;;
'node')
ps -ef |grep $1 |grep  -v "grep" |wc -l
;;
'redis')
ps -ef  |grep $1 |grep  -v "grep" |wc -l
;;
'tomcat')
ps -ef |grep $1 |grep  -v "grep" |wc -l
;;
'lsof')
lsof_total=`lsof |wc -l`
echo $lsof_total
;;
'lsof_tomcat')
 sudo lsof |grep tomcat |grep -v mem |wc -l

;;
'lsof_nginx')
lsof -c  nginx |grep -v mem |wc -l
;;
'lsof_mysql')
lsof -c  mysqld |grep -v mem |wc -l
;;
'lsof_redis')
lsof -c redis |grep -v mem |wc -l
;;
'lsof_node')
lsof -c node |grep -v mem |wc -l
;;

#if [ "$lsof_total" -gt "7000" ] ;then
#	echo "檔案數過多請檢查"
#else
#	echo "ok"
#fi
#;;
esac

