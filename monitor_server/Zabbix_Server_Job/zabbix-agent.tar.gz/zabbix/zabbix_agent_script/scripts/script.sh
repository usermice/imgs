#!/bin/bash

case $1 in
        #萬用型
        check.abnormal.ip)
            who | grep -Ev "185.167.12.11|47.242.92.1|tty" | wc -l
        ;;
        #cpu過高排行(包含啟動碼)
        check.cpu.high)
            ps -eo %cpu,%mem,pid,user,cmd --sort=-%cpu |head -10
        ;;
        check.netstat.redis)
            sudo netstat -antulp | grep redis |wc -l
        ;;
        check.netstat.mysqld)
            sudo netstat -antulp | grep mysqld |wc -l
        ;;
        check.netstat.all)
            sudo netstat -antulp | wc -l
        ;;
        #IP偵測
        #35.241.83.48 = 48.83.241.35.bc.googleusercontent.com
        #check.abnormal.ip)
        #        who | egrep -o '([0-9]{1,3}\.){3}[0-9]{1,3}' |grep -Ev "113.61.35.|185.167.12.13|185.167.12.11|103.136.110.141|103.136.110.142|60.250.109.160|103.248.20.34|60.250.109.161|103.139.240.236|48.83.241.35|180.232.82.93|180.232.82.90|130.105.154.57|175.176.33.26|180.232.82.94|180.232.82.92|180.232.82.91|112.199.92.42|112.199.92.35|112.199.92.95|112.207.104.187" | wc -l
        #;;
        #網域偵測
        #check.abnormal.ip.domain)
        #        who | egrep -o '([0-9]{1,3}\-){3}[0-9]{1,3}' |grep -Ev "59-124-243-25|61-219-164-205|bba191266|61-219-107-97|60-250-109-160" | wc -l
        #;;
        #帳號偵測
        check.abnormal.id)
                who | awk '{print$1}' | egrep -v "slotadmin|root|swadmin|mtadmin|ybop|blog|seadmin|sebot|ksadmin" | wc -l
        ;;
        #硬體掛載偵測
	    check.mondriver)
    		df -TH |awk NR!=1 |awk '{print $2}' |sort |uniq |grep -v tmpfs |grep -v ext |grep -v xfs|wc -l
	    ;;
        #登入數偵測
        check.login.amount)
                who |wc -l
        ;;
        #防火牆port偵測
        check.firewalld.port)
                sudo firewall-cmd --list-all | egrep "port|services" | awk -F ':' '{print$2}' > /tmp/port && sudo firewall-cmd --list-all | egrep "rule" | awk -F 'port="' '{print$2}' |awk -F '"' '{print$1}' >> /tmp/port && for i in `cat /tmp/port`;do [[ {443,80,22,1873,8002,10050,8081-8088/tcp,9081-9088/tcp,16303,17693,dhcpv6-client,http,https,443/tcp,80/tcp} =~ $i ]] || echo 0;done | grep 0 | wc -l
        ;;
        #目前登入清單
        check.who)
               who
        ;;
        #登入歷史清單前10個
        check.last)
               last -n 10
        ;;
        #=================服務偵測===============
        #MySQL服務偵測
        check.mysql.service)
                ps -ef  |grep mysql |grep  -v "grep" |wc -l
        ;;
        #Tomcat服務偵測
        check.tomcat.service)
                ps -ef  |grep tomcat$2 |grep  -v "grep" |wc -l
        ;;
        #node服務偵測
        check.node.service)
                ps -ef  |grep node |grep  -v "grep" |wc -l
        ;;
        #redis服務偵測
        check.redis.service)
                ps -ef  |grep redis |grep  -v "grep" |wc -l
        ;;
        #Node
        check.node.psef)
                ps -ef |grep node |wc -l
        ;;
        #=================檔案開啟數偵測===============
        #檔案開啟數偵測
        check.lsof)
               #lsof |wc -l
               cat /proc/sys/fs/file-nr |awk '{print $1}'
        ;;
        #Tomcat檔案開啟數偵測
        lsof.tomcat)
             #sudo lsof |grep tomcat |grep -v mem |wc -l
            sudo lsof -c java |grep -v mem  |wc -l
        ;;
        #Nginx檔案開啟數偵測
        lsof.nginx)
           sudo lsof -c  nginx |grep -v mem |wc -l
        ;;
        #Mysql檔案開啟數偵測
        lsof.mysql)
            sudo lsof -c  mysqld |grep -v mem |wc -l
        ;;
        #Redis檔案開啟數偵測
        lsof.redis)
            sudo lsof -c redis |grep -v mem |wc -l
        ;;
        #Node檔案開啟數偵測
        lsof.node)
            sudo lsof -c node |grep -v mem |wc -l
        ;;
        #=====================Nginx偵測=====================
        #Nginx開啟確認偵測
        check.nginx.ping)
                ps -ef | grep nginx\:\ master | grep -v grep | wc -l
        ;;
        #Nginx_active偵測
        check.nginx.active)
                curl -s http://127.0.0.1:10061/nginx_status |grep 'Active'|awk -F':' '{print $2}'
        ;;
        #Nginx_reading偵測
        check.nginx.reading)
                curl -s http://127.0.0.1:10061/nginx_status|grep 'Reading'|awk -F':' '{print $2}'|awk '{print $1}'
        ;;
        #Nginx_writing偵測
        check.nginx.writing)
                curl -s http://127.0.0.1:10061/nginx_status|grep 'Reading'|awk -F':' '{print $3}'|awk '{print $1}'
        ;;
        #Nginx_accepts偵測
        check.nginx.accepts)
                curl -s http://127.0.0.1:10061/nginx_status|awk NR==3 |awk '{print $1}'
        ;;
        #Nginx_handled偵測
        check.nginx.handled)
                curl -s http://127.0.0.1:10061/nginx_status|awk NR==3 |awk '{print $2}'
        ;;
        #Nginx_requests偵測
        check.nginx.requests)
                curl -s http://127.0.0.1:10061/nginx_status|awk NR==3 |awk '{print $3}'
        ;;
        #=======================Port偵測==========================
        #Tomcat_port偵測
        check.tomcat)
                netstat -lnt |grep $2 |wc -l
        ;;
        #MySQLPort偵測
        check.mysql.ping)
                netstat -lnt |grep 16303 |wc -l
        ;;
        #========================================================
        #Tomcat_log偵測(目前暫停使用，權限不足以監控，待解決)
        check.tomcat.log)
		echo "權限不夠，暫停使用========================================================"
                #TOM_DATE=`tail -n 500 /opt/lucky/logs/tomcat_${2}/catalina.out | awk -F '.' '{print $1}' | egrep "[0-9]{2}:[0-9]{2}:[0-9]{2}" | tail -n 1`
                #TOM_TIME=`date -d "${TOM_DATE}" +%s`    #轉時間戳記
                #NOW_TIME=`date '+%s'`                                   #當前時間
                #DIS=`expr ${NOW_TIME} - ${TOM_TIME}`    #時間差
                #TIME_THRESHOLD=300                                              #時間值
                #與時間值相比，小於時間值0，大於時間值回覆1
                #if [ ${DIS} -ge ${TIME_THRESHOLD} ];then
                #        echo 1
                #else
                #        echo 0
                #fi
        ;;
        #確認jsp檔案
        check.jsp)
                find /opt/webapps/ -type f -iname "*.jsp*" -o -iname "*.jspx*" -o -iname "*.py*" -o -iname "*.sh*" -o -iname "*.php*"| wc -l
        ;;
        #MySQL版本偵測
        check.mysql.version)
                /opt/apps/mysql/bin/mysql -V
        ;;
        #DNS解析時間確認
        check.dns.time)
                dig $1 @$2 |grep "Query time" | awk '{print$4}'
        ;;
        #DNS解析IP
        check.dns.ip)
                dig $1 @$2 |grep "^$1" |awk '{print $5}'
        ;;
        #=====================MySQL偵測=====================
        #MySQL_Slave是否執行中
        check.mysql.slave.status)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" |grep -e Slave_IO_Running -e Slave_SQL_Running:|grep Yes | wc -l
        ;;
        #MySQL_Slave是否延遲
        check.mysql.slave.delay)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" | grep Seconds_Behind_Master| awk '{print $2}'
        ;;
        #MySQL,SHOW GLOBAL STATUS,取的值請再後面加
        check.mysql.globalstaus)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "SHOW GLOBAL STATUS;" |grep $2 |awk '{print $2}'
        ;;
        #MySQL的MasterPos值(SQL執行數)
        check.mysql.masterpos)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show master status\G" | grep Position  |awk '{print $2}';
        ;;
        #MySQL的Master目前的執行檔案名
        check.mysql.masterfile)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show master status\G" | grep File | awk '{print $2}';
        ;;
        #MySQL的SlavePos值(SQL執行數)
        check.mysql.slavepos)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" | grep Exec_Master_Log_Pos | awk '{print $2}';
        ;;
        #MySQL的Slave目前的執行檔案名
        check.mysql.slavefile)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" | grep Relay_Master_Log_File | awk '{print $2}';
        ;;
        check.mysql.processlist)         
            /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "select count(*) from information_schema.processlist;"|awk '{print $(NF-1)}'|sed -n "2,2p"
        ;;
        #NCat指令PING該PORT
        ncping)
                nc -vz $2 $3  2>&1 | grep seconds |awk '{print$9}'
        ;;
        #硬碟搜尋偵測
        check.disk.discovery)
                #获取磁盘名称
                diskarray=(`cat /proc/diskstats |grep -E "\bsd[abcdefg]\b|\bxvd[abcdefg]\b"|grep -i "\b$1\b"|awk '{print $3}'|sort|uniq   2>/dev/null`)
                length=${#diskarray[@]}
                printf "{\n"
                printf  '\t'"\"data\":["
                for ((i=0;i<$length;i++))
                do
                                printf '\n\t\t{'
                                printf "\"{#DISK_NAME}\":\"${diskarray[$i]}\"}"
                                if [ $i -lt $[$length-1] ];then
                                                printf ','
                                fi
                done
                printf  "\n\t]\n"
                printf "}\n"
        ;;
        ckeck_fackingcoin_001)
                ps -ef |grep kdevtmpfsi |grep -v grep |wc -l
        ;;
        ckeck_fackingcoin_002)
                ps -ef |grep kinsing |grep -v grep |wc -l
        ;;
        ckeck_fackingcoin_003)
                find /tmp -name "kdevtmpfsi" |wc -l
        ;;
        ckeck_fackingcoin_004)
                find /tmp -name "kinsing" |wc -l
        ;;
        #=====================使用頻率排行===================
        #程式的CPU使用頻率
        check.ps.cpu)
                ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head
        ;;
        #程式的RAM使用頻率
        check.ps.ram)
                ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head
        ;;
        #網路使用頻率
        check.iftop)
                sudo iftop -t -s 10
        ;;
        #測試用
        paul)
                echo $1
                echo $2
                echo $3
        ;;
        #其他測試?
        eie)
                ter=Mount.status,df -TH |awk NR!=1 |awk '{print $2}' |sort |uniq |grep -v tmpfs |grep -v ext |grep -v xfs|wc -l
                3333=firewalld_status,ps -ef|grep firewalld|grep -v grep|wc -l
                21222=Login.status,who | egrep -o '([0-9]{1,3}\.){3}[0-9]{1,3}' |grep -v "113.61.35." | wc -l
                333=Loginuser.status,who | awk '{print$1}' | egrep -v "root|swadmin|mtadmin|ybop|blog" | wc -l
                2323=Block_login,ps aux | grep block_login_ip.py | grep -v grep | wc -l
        ;;
        #GitLab的更新Type1
        git.update)
                export GIT_SSL_NO_VERIFY=true
                git config --global http.sslVerify "false"
                cd /home/mtadmin/apps/zabbix/zabbix_agent_script/
                git fetch --all
		        #git pull git@gitlab.idcduty.com/jackwu/zabbix_agent_script:jackwu/zabbix_agent_script.git 
		        #git pull git@gitlab.idcduty.com:jackwu/zabbix_agent_script.git
		        git pull
        ;;
        #GitLab的更新Type2
        #錯誤指令時的回覆
        *)
                echo "[Error沒有這個值]"
esac