#!/bin/bash

case $1 in

        check.abnormal.ip)
                who | egrep -o '([0-9]{1,3}\.){3}[0-9]{1,3}' |grep -Ev "113.61.35.|185.167.12.13|185.167.12.11|103.136.110.141|103.136.110.142|59.124.243.25|103.139.240.236" | wc -l
        ;;
        check.abnormal.ip.domain)
                who | egrep -o '([0-9]{1,3}\-){3}[0-9]{1,3}' |grep -Ev "59-124-243-25|192-168-0-0" | wc -l
        ;;
        check.abnormal.id)
                who | awk '{print$1}' | egrep -v "slotadmin|root|swadmin|mtadmin|ybop|blog|seadmin|sebot" | wc -l
        ;;
	    check.mondriver)
    		df -TH |awk NR!=1 |awk '{print $2}' |sort |uniq |grep -v tmpfs |grep -v ext |grep -v xfs|wc -l
	    ;;
	    check.mysql.service)
                ps -ef  |grep mysql |grep  -v "grep" |wc -l
        ;;
        check.tomcat.service)
                ps -ef  |grep tomcat$2 |grep  -v "grep" |wc -l
        ;;
        check.node.service)
                ps -ef  |grep node |grep  -v "grep" |wc -l
        ;;
        check.redis.service)
                ps -ef  |grep redis |grep  -v "grep" |wc -l
        ;;

        check.login.amount)
                who |wc -l
        ;;
        check.lsof)
               #lsof |wc -l
               cat /proc/sys/fs/file-nr |awk '{print $1}'
        ;;
        lsof.tomcat)
             #sudo lsof |grep tomcat |grep -v mem |wc -l
            sudo lsof -c java |grep -v mem  |wc -l
        ;;
        lsof.nginx)
           sudo lsof -c  nginx |grep -v mem |wc -l
        ;;
        lsof.mysql)
            sudo lsof -c  mysqld |grep -v mem |wc -l
        ;;
        lsof.redis)
            sudo lsof -c redis |grep -v mem |wc -l
        ;;
        lsof.node)
            sudo lsof -c node |grep -v mem |wc -l
        ;;

        check.nginx.ping)
                ps -ef | grep nginx\:\ master | grep -v grep | wc -l
        ;;
        check.nginx.active)
                curl -s http://127.0.0.1:10061/nginx_status |grep 'Active'|awk -F':' '{print $2}'
        ;;
        check.nginx.reading)
                curl -s http://127.0.0.1:10061/nginx_status|grep 'Reading'|awk -F':' '{print $2}'|awk '{print $1}'
        ;;
        check.nginx.writing)
                curl -s http://127.0.0.1:10061/nginx_status|grep 'Reading'|awk -F':' '{print $3}'|awk '{print $1}'
        ;;
        check.nginx.writing)
                curl -s http://127.0.0.1:10061/nginx_status|grep 'Reading'|awk -F':' '{print $3}'|awk '{print $1}'
        ;;
        check.nginx.accepts)
                curl -s http://127.0.0.1:10061/nginx_status|awk NR==3 |awk '{print $1}'
        ;;
        check.nginx.handled)
                curl -s http://127.0.0.1:10061/nginx_status|awk NR==3 |awk '{print $2}'
        ;;
        check.nginx.requests)
                curl -s http://127.0.0.1:10061/nginx_status|awk NR==3 |awk '{print $3}'
        ;;
        check.tomcat)
                        netstat -lnt |grep $2 |wc -l
        ;;
        check.node.psef)
            ps -ef |grep node |wc -l
        ;;
        check.tomcat.log)
		#權限不夠，暫停使用========================================================
		echo "權限不夠，暫停使用========================================================"
                #TOM_DATE=`tail -n 500 /opt/lucky/logs/tomcat_${2}/catalina.out | awk -F '.' '{print $1}' | egrep "[0-9]{2}:[0-9]{2}:[0-9]{2}" | tail -n 1`
                #TOM_TIME=`date -d "${TOM_DATE}" +%s`    #轉時間戳記
                #NOW_TIME=`date '+%s'`                                   #當前時間
                #DIS=`expr ${NOW_TIME} - ${TOM_TIME}`    #時間差
                #TIME_THRESHOLD=300                                              #時間值
                #與時間值相比，小於時間值0，大於時間值回覆1
                #if [ ${DIS} -ge ${TIME_THRESHOLD} ];then
                #        echo 1
                #else
                #        echo 0
                #fi
        ;;
        check.abnormal.ip.domain.type2)
                who | egrep -o '([0-9]{1,3}\-){3}[0-9]{1,3}' |grep -Ev "59-124-243-25|192-168-0-0|61-219-164-205" | wc -l
        ;;
        check.abnormal.ip.type2)
            who | egrep -o '([0-9]{1,3}\.){3}[0-9]{1,3}' |grep -Ev "185.167.12.13|185.167.12.11|103.139.240.236" | wc -l
        ;;
        check.abnormal.id.type2)
                who | awk '{print$1}' | egrep -v "root|swadmin|mtadmin|ybop|blog|seadmin|sebot|slotman|slotadmin" | wc -l
        ;;
        check.jsp)
                find /opt/webapps/ -type f -iname "*.jsp*" -o -iname "*.jspx*" -o -iname "*.py*" -o -iname "*.sh*" -o -iname "*.php*"| wc -l
        ;;
        check.firewalld.port)
                sudo firewall-cmd --list-all | egrep "port|services" | awk -F ':' '{print$2}' > /tmp/port && sudo firewall-cmd --list-all | egrep "rule" | awk -F 'port="' '{print$2}' |awk -F '"' '{print$1}' >> /tmp/port && for i in `cat /tmp/port`;do [[ {443,80,22,1873,8002,10050,8081-8088/tcp,9081-9088/tcp,16303,17693,dhcpv6-client,http,https,443/tcp,80/tcp} =~ $i ]] || echo 0;done | grep 0 | wc -l
        ;;
        check.mysql.version)
                /opt/apps/mysql/bin/mysql -V
        ;;
        check.mysql.ping)
                netstat -lnt |grep 16303 |wc -l
        ;;
        check.dns.time)
                dig $1 @$2 |grep "Query time" | awk '{print$4}'
        ;;
        check.dns.ip)
                dig $1 @$2 |grep "^$1" |awk '{print $5}'
        ;;
        check.mysql.slave.status)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" |grep -e Slave_IO_Running -e Slave_SQL_Running:|grep Yes | wc -l
        ;;
        check.mysql.slave.delay)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" | grep Seconds_Behind_Master| awk '{print $2}'
        ;;
        check.mysql.globalstaus)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "SHOW GLOBAL STATUS;" |grep $2 |awk '{print $2}'
        ;;
        check.mysql.masterpos)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show master status\G" | grep Position  |awk '{print $2}';
        ;;
        check.mysql.masterfile)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show master status\G" | grep File | awk '{print $2}';
        ;;
        check.mysql.slavepos)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" | grep Exec_Master_Log_Pos | awk '{print $2}';
        ;;
        check.mysql.slavefile)
                /opt/apps/mysql/bin/mysql -uzabbixmonitor -S /opt/data/data_16303/mysql.sock -e "show slave status\G" | grep Relay_Master_Log_File | awk '{print $2}';
        ;;
        check.disk.discovery)
                #获取磁盘名称
                diskarray=(`cat /proc/diskstats |grep -E "\bsd[abcdefg]\b|\bxvd[abcdefg]\b"|grep -i "\b$1\b"|awk '{print $3}'|sort|uniq   2>/dev/null`)
                length=${#diskarray[@]}
                printf "{\n"
                printf  '\t'"\"data\":["
                for ((i=0;i<$length;i++))
                do
                                printf '\n\t\t{'
                                printf "\"{#DISK_NAME}\":\"${diskarray[$i]}\"}"
                                if [ $i -lt $[$length-1] ];then
                                                printf ','
                                fi
                done
                printf  "\n\t]\n"
                printf "}\n"
        ;;
        check.ps.cpu)
                ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head
        ;;
        check.ps.ram)
                ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head
        ;;
        check.iftop)
                sudo iftop -t -s 10
        ;;
        paul)
                echo $1
                echo $2
                echo $3
        ;;



        eie)
                ter=Mount.status,df -TH |awk NR!=1 |awk '{print $2}' |sort |uniq |grep -v tmpfs |grep -v ext |grep -v xfs|wc -l
                3333=firewalld_status,ps -ef|grep firewalld|grep -v grep|wc -l
                21222=Login.status,who | egrep -o '([0-9]{1,3}\.){3}[0-9]{1,3}' |grep -v "113.61.35." | wc -l
                333=Loginuser.status,who | awk '{print$1}' | egrep -v "root|swadmin|mtadmin|ybop|blog" | wc -l
                2323=Block_login,ps aux | grep block_login_ip.py | grep -v grep | wc -l
        ;;
        git.update)
                export GIT_SSL_NO_VERIFY=true
                cd /home/mtadmin/apps/zabbix/zabbix_agent_script/
		#git pull git@gitlab.idcduty.com/jackwu/zabbix_agent_script:jackwu/zabbix_agent_script.git 
		git pull git@gitlab.idcduty.com:jackwu/zabbix_agent_script.git
        ;;
        git.update2)
            su  mtadmin -c "
                export GIT_SSL_NO_VERIFY=true
                cd /home/mtadmin/apps/zabbix/zabbix_agent_script/
                git pull git@103.139.241.21:jackwu/zabbix_agent_script.git 
		    "
        ;;
        *)
                echo "[Error沒有這個值],YouCanInput目前可用的值有[Abnormal.ip,Abnormal-ip,Abnormal.id,login.amount,git.update]"
esac

