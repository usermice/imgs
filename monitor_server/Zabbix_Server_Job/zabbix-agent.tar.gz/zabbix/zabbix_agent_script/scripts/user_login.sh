#!/bin/bash
ur=$(who |wc -l)
if [ $ur -gt 5 ];then
   echo $ur
   #echo ‘1‘
else
   echo $ur
   #echo ‘2‘
fi
