#!/bin/bash

rpm -qa | grep zabbix-agent &>/dev/null
if [ $? -eq 0 ];then
    echo "========================已經安裝yum版Zabbix========================"
    read -p "是否刪除Y/N" yumzabbixremove
    case $yumzabbixremove in
        Y|y)
            echo "========================刪除yum版Zabbix========================"
            yum remove -y zabbix-agent
        ;;
        N|n)
            echo "========================保留yum版Zabbix，關閉安裝程式========================"
            exit
        ;;
        *)
            echo "========================輸入錯誤，關閉安裝程式========================"
            exit
        ;;
    esac
else
        echo "========================檢測無yum版Zabbix========================"
fi

yum install -y git wget vim unzip ntp nc
yum install bash-completion -y && source /etc/profile
grep "mtadmin" /etc/passwd &>/dev/null
if [ $? -ne 0 ];then
        groupadd mtadmin && useradd -g mtadmin mtadmin
fi
   /usr/bin/ls /home/mtadmin/apps/zabbix/sbin/zabbix_agentd &>/dev/null
if [ $? -eq 0 ];then
    netstat -lntp|grep 10050|awk '{print $7}'|awk -F'/' '{print $1}'|sort|uniq|xargs kill
    sleep 2
    rm -fr /home/mtadmin/*
fi
systemctl enable ntpd
systemctl start ntpd
#============================
su mtadmin -c "
    cd /home/mtadmin/
    wget --http-user="downfile"  --http-password="work5net9+hk4g4ej03xu3m06"  http://file.idcduty.com/softfile/setup/source/zabbix-agent-web%2Bdb.zip
    sleep 2
    unzip zabbix-agent-web+db.zip &&  rm -rf zabbix-agent-web+db.zip
    sleep 1
    chmod +x /home/mtadmin/apps/zabbix/scripts/*
    chmod +x /home/mtadmin/apps/zabbix/sbin/zabbix_agentd
"
#============================
server_ip=`hostname -I |awk '{print $1}'`
sed -i  "s/zabbixclient-500cp-slave/zabbixclient-$server_ip/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
#============================
su mtadmin -c "
    grep Hostname= /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
    /home/mtadmin/apps/zabbix/sbin/zabbix_agentd
"
#============================
grep 'zabbix_agentd' /etc/rc.local &>/dev/null
if [ $? -ne 0 ];then
    echo -e "########zabbix开机自启########\nsu mtadmin -c \"/home/mtadmin/apps/zabbix/sbin/zabbix_agentd\"" >> /etc/rc.local
fi
chmod +x /etc/rc.d/rc.local

firewall-cmd --permanent --new-ipset=zabbix_whitelist --type=hash:ip
echo "" /etc/firewalld/ipsets/zabbix_whitelist.xml
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry="103.139.241.119"
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry="192.168.10.119"
firewall-cmd --reload
firewall-cmd --permanent --ipset=zabbix_whitelist --get-entries
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source ipset=zabbix_whitelist port port="10051" protocol="tcp" accept'
firewall-cmd --reload
firewall-cmd --permanent --new-ipset=zabbix_whitelist --type=hash:ip
firewall-cmd --reload
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=103.139.241.119
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.192/26
firewall-cmd --reload
firewall-cmd --permanent --ipset=zabbix_whitelist --get-entries
echo "Line End"
#判斷是否已經下載gitlab上的資料
cd /home/mtadmin/apps/zabbix/
if [ ! -d "zabbix_agent_script"  ];then
su  mtadmin -c "
cd /home/mtadmin/apps/zabbix/
git clone  https://itman:work5net9@gitlab.idcduty.com/jackwu/zabbix_agent_script.git
"
else
    echo "========================Git已經Clone========================"
fi

#判斷是否已設定zabbidinclude
grep "zabbix_agent_script" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
if [ $? -ne 0 ];then
        su mtadmin -c "
        echo 'Include=/home/mtadmin/apps/zabbix/zabbix_agent_script/conf/*.conf' >>/home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
        pkill -9 zabbix_agentd
		/home/mtadmin/apps/zabbix/sbin/zabbix_agentd
	"
else
        echo "========================Zabbix_Include已經做過了========================"
fi

#.ssh檔寫入
su mtadmin -c "
mkdir /home/mtadmin/.ssh
cp -fr /home/mtadmin/apps/zabbix/zabbix_agent_script/key/* /home/mtadmin/.ssh/
cd /home/mtadmin/.ssh/
echo '    Host gitlab.idcduty.com' >> config
echo '     IdentityFile ~/.ssh/id_rsa.itmangitlab' >> config
chmod 600 /home/mtadmin/.ssh/id_rsa.itmangitlab
chmod 600 /home/mtadmin/.ssh/config
"
echo "========================公鑰導入完成========================"

#設定Zabbix主機
grep "103.139.241.119" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
if [ $? -ne 0 ];then
    sed -i  "s/Server=103.86.85.91/Server=103.139.241.119,185.167.15.200/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
    sed -i  "s/ServerActive=103.86.85.91:10051/ServerActive=185.167.15.200:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
else
        echo "========================zabbixConf_IP已存在========================"
fi


#設定GITuser
git config --global user.email "itman@example.com"
git config --global user.name "itman"
echo "========================GIT設定========================" 

su mtadmin -c "
pkill -9 zabbix_agentd
/home/mtadmin/apps/zabbix/sbin/zabbix_agentd
"
echo "========================重啟ZABBIX完成========================" 
grep "ecktLsEmENWQJN4E" /home/mtadmin/.ssh/known_hosts
if [ $? -ne 0 ];then
	echo "========================known_host_IP設定========================" 
    su mtadmin -c "
    echo 'gitlab.idcduty.com ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBI6M9ur9MxfxhrUp/Eb81Ko5m1LPtY1EQC3Udapc9v9s65FUSEkx3KupAe+9vXAjWk8ecktLsEmENWQJN4E/i6Y=' >> /home/mtadmin/.ssh/known_hosts
    "
else
        echo "=========================known_host_IP已存在========================"
fi
su mtadmin -c "
       cd /home/mtadmin/apps/zabbix/zabbix_agent_script/
       git pull
    "
chown -R mtadmin.mtadmin /home/mtadmin/apps/zabbix/zabbix_agent_script/.git/FETCH_HEAD
grep "^Server=" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
grep "^ServerActive=" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
echo "請選擇要添加的Proxy伺服器"
echo "1. Zabbix_Proxy_185.167.15.201"
echo "2. Zabbix_Proxy_185.167.15.202"
echo "3. Zabbix_Proxy_185.167.15.203"
echo "4. Zabbix_Proxy_185.167.15.204"
echo "5. Zabbix_Proxy_185.167.15.205"
echo "6. Zabbix_Proxy_185.167.15.206"
echo "7. Zabbix_Proxy_185.167.15.207"
echo "8. 略過"
echo "9. Zabbix_Proxy_185.167.15.209"
echo "10. Zabbix_Proxy_185.167.15.210"
while true;do
        read -p "請輸入1~6__=" listnum
            case $listnum in
                1)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.201/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.201:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                2)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.202/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.202:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                3)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.203/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.203:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                4)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.204/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.204:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                5)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.205/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.205:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                6)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.206/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.206:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                7)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.207/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.207:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                8)
                    break;;
                9)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.209/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.209:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                10)
                    sed -i  "s/Server=103.139.241.119,185.167.15.200/Server=103.139.241.119,185.167.15.200,185.167.15.210/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    sed -i  "s/ServerActive=185.167.15.200:10051/ServerActive=185.167.15.200:10051,185.167.15.210:10051/g" /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf
                    break;;
                *)
                continue;;
            esac
    done
pkill -9 zabbix_agentd
su mtadmin -c "/home/mtadmin/apps/zabbix/sbin/zabbix_agentd"
echo "================zabbix，設定IP==========設定前"
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Server="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^ServerActive="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Hostname="
echo "================zabbix，防火牆IP==========設定前"
firewall-cmd --permanent --ipset=zabbix_whitelist --get-entries
firewall-cmd --permanent --add-rich-rule='rule family="ipv4" source ipset=zabbix_whitelist port port="10050" protocol="tcp" accept'
firewall-cmd --reload
firewall-cmd --permanent --new-ipset=zabbix_whitelist --type=hash:ip
firewall-cmd --reload
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=103.139.241.119
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.200
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.201
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.202
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.203
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.204
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.205
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.206
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.207
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.209
firewall-cmd --permanent --ipset=zabbix_whitelist --add-entry=185.167.15.210
firewall-cmd --reload
echo "================zabbix，防火牆IP==========設定後"
firewall-cmd --permanent --ipset=zabbix_whitelist --get-entries
echo "======================"
echo "zabbixSetting"
echo "================zabbix，設定IP==========設定後"
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Server="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^ServerActive="
cat /home/mtadmin/apps/zabbix/etc/zabbix_agentd.conf | grep "^Hostname="

echo "Line End"

